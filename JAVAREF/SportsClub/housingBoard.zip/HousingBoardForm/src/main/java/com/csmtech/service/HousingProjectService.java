package com.csmtech.service;

import java.util.List;

import com.csmtech.model.HousingProject;

public interface HousingProjectService {

	List<HousingProject>  getAllProjects(); 
}
