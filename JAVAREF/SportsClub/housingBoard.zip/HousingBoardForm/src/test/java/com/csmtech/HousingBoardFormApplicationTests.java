package com.csmtech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HousingBoardFormApplicationTests {

	@Test
	void contextLoads() {
	}

}
